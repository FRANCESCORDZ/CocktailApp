package com.example.redolfidezan_cocktailapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CocktailViewModel : ViewModel() {
    val cocktails = MutableLiveData<List<Cocktail>>()

    fun searchCocktails(query: String) {
        RetrofitClient.apiService.searchCocktails(query).enqueue(object : Callback<CocktailResponse> {
            override fun onResponse(call: Call<CocktailResponse>, response: Response<CocktailResponse>) {
                cocktails.value = response.body()?.drinks ?: emptyList()
            }

            override fun onFailure(call: Call<CocktailResponse>, t: Throwable) {
                cocktails.value = emptyList()
            }
        })
    }
}
