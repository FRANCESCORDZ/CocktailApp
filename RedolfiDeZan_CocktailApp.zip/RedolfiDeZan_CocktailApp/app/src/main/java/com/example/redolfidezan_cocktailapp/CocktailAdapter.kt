package com.example.redolfidezan_cocktailapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class CocktailAdapter(
    private val cocktails: List<Cocktail>,
    private val onClick: (Cocktail) -> Unit
) : RecyclerView.Adapter<CocktailAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.cocktail_name)
        val image: ImageView = view.findViewById(R.id.cocktail_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cocktail, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cocktail = cocktails[position]
        holder.name.text = cocktail.strDrink
        holder.image.load(cocktail.strDrinkThumb)
        holder.itemView.setOnClickListener { onClick(cocktail) }
    }

    override fun getItemCount() = cocktails.size
}
