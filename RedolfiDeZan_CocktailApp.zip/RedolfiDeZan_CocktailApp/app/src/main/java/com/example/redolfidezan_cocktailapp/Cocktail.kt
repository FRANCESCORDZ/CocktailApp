package com.example.redolfidezan_cocktailapp

import java.io.Serializable

data class Cocktail(
    val idDrink: String,
    val strDrink: String,
    val strDrinkThumb: String,
    val strIngredient1: String?
) : Serializable

