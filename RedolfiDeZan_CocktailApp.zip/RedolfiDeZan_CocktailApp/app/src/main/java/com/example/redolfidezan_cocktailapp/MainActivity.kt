package com.example.redolfidezan_cocktailapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private val viewModel: CocktailViewModel by viewModels()
    private lateinit var adapter: CocktailAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchInput = findViewById<EditText>(R.id.search_input)
        val searchButton = findViewById<ImageButton>(R.id.search_button)
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)

        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.cocktails.observe(this) { cocktails ->
            adapter = CocktailAdapter(cocktails) { cocktail ->
                val intent = Intent(this, DetailActivity::class.java)
                intent.putExtra("cocktail", cocktail)  // Passa l'oggetto Cocktail
                startActivity(intent)

            }
            recyclerView.adapter = adapter
        }

        searchButton.setOnClickListener {
            val query = searchInput.text.toString()
            if (query.isNotEmpty()) {
                viewModel.searchCocktails(query)
            }
        }
    }
}

