package com.example.redolfidezan_cocktailapp

data class CocktailResponse(val drinks: List<Cocktail>?)
data class Cocktail(
    val idDrink: String,
    val strDrink: String,
    val strDrinkThumb: String,
    val strIngredient1: String?
)
