package com.example.redolfidezan_cocktailapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface CocktailApiService {
    @GET("search.php")
    fun searchCocktails(@Query("s") name: String): Call<CocktailResponse>
}
