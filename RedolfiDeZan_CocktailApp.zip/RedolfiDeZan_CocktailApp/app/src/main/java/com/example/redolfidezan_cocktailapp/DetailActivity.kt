package com.example.redolfidezan_cocktailapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Parcelable
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import coil.load

class DetailActivity : AppCompatActivity() {
    @SuppressLint("CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val cocktail = intent.getSerializableExtra("cocktail") as Cocktail?

        if (cocktail != null) {
            findViewById<TextView>(R.id.detail_name).text = cocktail.strDrink
        }


        val image = findViewById<ImageView>(R.id.detail_image)
        val name = findViewById<TextView>(R.id.detail_name)
        val ingredients = findViewById<TextView>(R.id.detail_ingredients)

        if (cocktail != null) {
            image.load(cocktail.strDrinkThumb)
        }
        if (cocktail != null) {
            name.text = cocktail.strDrink
        }
        if (cocktail != null) {
            ingredients.text = "Ingrediente principale: ${cocktail.strIngredient1}"
        }


    }
}
