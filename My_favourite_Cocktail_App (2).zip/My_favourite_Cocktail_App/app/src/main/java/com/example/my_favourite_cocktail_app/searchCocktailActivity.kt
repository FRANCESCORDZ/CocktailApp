package com.example.my_favourite_cocktail_app

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import java.io.File
import java.io.IOException

class searchCocktailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SearchCocktailScreen()
        }
    }
}

@Composable
fun SearchCocktailScreen() {
    var searchQuery by remember { mutableStateOf("") }
    var cocktails by remember { mutableStateOf<List<Cocktail>?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Enter cocktail name") },
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Button(onClick = {
                coroutineScope.launch {
                    searchCocktail(searchQuery, { cocktails = it }, { errorMessage = it })
                }
            }) {
                Text("Search")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        errorMessage?.let {
            Text(text = "Error: $it", color = Color.Red, modifier = Modifier.padding(8.dp))
        }

        LazyColumn {
            cocktails?.let {
                items(it) { cocktail ->
                    CocktailCard(cocktail) {
                        addCocktailToFavourites(context, cocktail.name)
                    }
                }
            }
        }
    }
}

@Composable
fun CocktailCard(cocktail: Cocktail, onAddToFavourite: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF5EA))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            AsyncImage(
                model = cocktail.imageUrl,
                contentDescription = cocktail.name,
                modifier = Modifier.fillMaxWidth().height(200.dp)
            )

            Text(text = cocktail.name, fontWeight = FontWeight.Bold)
            Text(text = "Category: ${cocktail.category ?: "Unknown"}")
            Text(text = "Alcoholic: ${cocktail.alcoholic ?: "Unknown"}")

            Button(onClick = onAddToFavourite, modifier = Modifier.padding(top = 8.dp)) {
                Text("Add to Favourite")
            }
        }
    }
}

fun addCocktailToFavourites(context: Context, cocktailName: String) {
    val file = File(context.filesDir, "favorites.txt")

    // Controlla se il nome esiste già nel file per evitare duplicati
    val existingNames = if (file.exists()) file.readLines() else emptyList()

    if (cocktailName !in existingNames) {
        file.appendText("$cocktailName\n") // Aggiunge un nuovo cocktail con una nuova riga
    }
}

fun searchCocktail(name: String, onSuccess: (List<Cocktail>) -> Unit, onError: (String) -> Unit) {
    val url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=$name"
    val request = Request.Builder().url(url).build()
    val client = OkHttpClient()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            onError("Failed to fetch data.")
        }

        override fun onResponse(call: Call, response: Response) {
            val body = response.body?.string()
            if (body.isNullOrEmpty()) {
                onError("Empty response")
                return
            }

            val json = JSONObject(body)
            val drinks = json.optJSONArray("drinks") ?: return onError("No results found")
            val cocktails = mutableListOf<Cocktail>()

            for (i in 0 until drinks.length()) {
                val drink = drinks.getJSONObject(i)
                cocktails.add(
                    Cocktail(
                        drink.getString("strDrink"),
                        drink.optString("strDrinkThumb", ""),
                        drink.optString("strCategory", "Unknown"),
                        drink.optString("strAlcoholic", "Unknown")
                    )
                )
            }

            onSuccess(cocktails)
        }
    })
}

data class Cocktail(val name: String, val imageUrl: String, val category: String?, val alcoholic: String?)
