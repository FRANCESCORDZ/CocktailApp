package com.example.my_favourite_cocktail_app

import android.content.Context
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import java.io.File
import java.io.IOException

class MyFavouritesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyFavouritesScreen()
        }
    }
}

@Composable
fun MyFavouritesScreen() {
    val context = LocalContext.current
    var cocktails by remember { mutableStateOf<List<Cocktail>>(emptyList()) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val names = getFavouriteCocktails(context)
            searchCocktailDetails(names) { cocktails = it }
        }
    }

    LazyColumn {
        items(cocktails) { cocktail ->
            CocktailCardf(cocktail) {
                // Rimuove il cocktail dai preferiti quando il pulsante viene premuto
                removeCocktailFromFavourites(context, cocktail.name)
                // Rimuove il cocktail dalla lista dopo la rimozione
                cocktails = cocktails.filterNot { it.name == cocktail.name }
            }
        }
    }
}

@Composable
fun CocktailCardf(cocktail: Cocktail, onRemoveFromFavourites: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF5EA))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            AsyncImage(
                model = cocktail.imageUrl,
                contentDescription = cocktail.name,
                modifier = Modifier.fillMaxWidth().height(200.dp)
            )

            Text(text = cocktail.name, fontWeight = FontWeight.Bold)
            Text(text = "Category: ${cocktail.category ?: "Unknown"}")
            Text(text = "Alcoholic: ${cocktail.alcoholic ?: "Unknown"}")

            Button(onClick = onRemoveFromFavourites, modifier = Modifier.padding(top = 8.dp)) {
                Text("Remove from Favourites")
            }
        }
    }
}

fun getFavouriteCocktails(context: Context): List<String> {
    val file = File(context.filesDir, "favorites.txt")
    return if (file.exists()) file.readLines() else emptyList()
}

fun searchCocktailDetails(names: List<String>, onSuccess: (List<Cocktail>) -> Unit) {
    val client = OkHttpClient()
    val cocktails = mutableListOf<Cocktail>()

    val remaining = names.toMutableList() // Manteniamo traccia dei cocktail ancora da caricare

    names.forEach { name ->
        val url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=$name"
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                remaining.remove(name) // Rimuove cocktail falliti dal tracking
                if (remaining.isEmpty()) onSuccess(cocktails) // Quando tutti sono processati
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { body ->
                    val json = JSONObject(body)
                    json.optJSONArray("drinks")?.let { drinks ->
                        if (drinks.length() > 0) {
                            val drink = drinks.getJSONObject(0)
                            cocktails.add(
                                Cocktail(
                                    drink.getString("strDrink"),
                                    drink.optString("strDrinkThumb", ""),
                                    drink.optString("strCategory", "Unknown"),
                                    drink.optString("strAlcoholic", "Unknown")
                                )
                            )
                        }
                    }
                }
                remaining.remove(name)
                if (remaining.isEmpty()) onSuccess(cocktails) // Quando tutti i cocktail sono stati processati
            }
        })
    }
}

fun removeCocktailFromFavourites(context: Context, cocktailName: String) {
    val file = File(context.filesDir, "favorites.txt")

    if (file.exists()) {
        val lines = file.readLines().toMutableList()
        lines.remove(cocktailName) // Rimuove il nome del cocktail dai preferiti
        file.writeText(lines.joinToString("\n")) // Scrive di nuovo il file senza quel cocktail
    }
}
