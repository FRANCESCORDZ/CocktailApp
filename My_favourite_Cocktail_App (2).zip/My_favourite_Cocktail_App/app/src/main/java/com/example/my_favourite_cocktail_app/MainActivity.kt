package com.example.my_favourite_cocktail_app

import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.my_favourite_cocktail_app.ui.theme.Purple40

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HomeScreen(
                onSearchCocktailActivity = { startActivity(Intent(this, searchCocktailActivity::class.java)) },
                onMyFavouritesActivity = { startActivity(Intent(this, MyFavouritesActivity::class.java)) },
            )
        }
    }
}

@Composable
fun HomeScreen(
    onSearchCocktailActivity: () -> Unit,
    onMyFavouritesActivity: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        MainButton(text = "Search Cocktail", onClick = onSearchCocktailActivity)
        Spacer(modifier = Modifier.height(16.dp))
        MainButton(text = "My favourites", onClick = onMyFavouritesActivity)
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun MainButton(text: String, onClick: () -> Unit, backgroundColor: Color = Purple40, textColor: Color = Color.White) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
        modifier = Modifier.height(50.dp).width(270.dp)
    ) {
        Text(text = text, fontSize = 18.sp, color = textColor)
    }
}